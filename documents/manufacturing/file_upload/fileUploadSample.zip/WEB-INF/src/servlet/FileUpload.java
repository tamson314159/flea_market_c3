package servlet;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class FileUpload extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラーメッセージ用変数
		String errorMessage = "";


		try {
			//  enctype="multipart/form-data”で送られてきたフォームの情報を受け取る
			if (ServletFileUpload.isMultipartContent(request)) {

				// ファクトリー生成
				DiskFileItemFactory factory = new DiskFileItemFactory();

				// ファイルの最大容量を設定
				ServletFileUpload upload = new ServletFileUpload(factory);
				upload.setSizeMax(-1); // リクエストの最大サイズ。無制限の場合は-1。
				upload.setFileSizeMax(1024 * 1024); // ファイルの最大サイズ。今回は1MB（1024 * 1024 KB）

				// 前の画面から送信されたデータを種類によって分割する
				List<FileItem> items = upload.parseRequest(request);

				// 全フィールドに対する繰り返し処理を行う
				for (FileItem item : items) {
					if (item.isFormField()) {
						// type="file"以外のフィールド

						// フィールド名と値を取得
						String fieldName = item.getFieldName(); // name属性を取得
						String fieldValue = item.getString("UTF-8"); // value属性を取得（文字コードも指定する）

						// リクエストスコープに、フィールド名と値を設定
						request.setAttribute(fieldName, fieldValue);
					} else {
						// type="file"のフィールド

						// ファイル名を取得
						File f = new File(item.getName());

						// ファイル格納先を設定（自分のプロジェクト内の特定のフォルダ）
						String path = getServletContext().getRealPath("file");

						// 指定したフォルダ（path）の階層にファイルを書き込む（アップロードする）
						item.write(new File(path + "/" + f.getName()));

						// リクエストスコープに、ファイル名を設定
						request.setAttribute("fileName", f.getName());
					}
				}
			}
		} catch (FileUploadException e) {
			// upload.parseRequest(request)で失敗
			errorMessage = "送信されたデータの分割に失敗しました";
		} catch (IOException e) {
			// item.write()で失敗
			errorMessage = "ファイルのアップロードに失敗しました";
		} catch (Exception e) {
			// その他
			errorMessage = "予期せぬエラーが発生しました";
		} finally {
			// 結果画面へ遷移
			request.setAttribute("errorMessage", errorMessage);
			request.getRequestDispatcher("/view/uploadResult.jsp").forward(request, response);
		}

	}

}
